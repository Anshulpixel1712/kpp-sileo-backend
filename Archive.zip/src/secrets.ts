const secrets = {
  type: "service_account",
  project_id: "charming-well-424808-a3",
  private_key_id: "fa9a9895fd8e94b219e6c4eab0e8667c33b2728d",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCmIjUQpRmqBBNv\n45ZOfsIHRTCvDvXMCdoAaeBe5r/xn5RFsfK5o+GCS0tSN/QLOgaPm8pNOG5yWRhs\npneSeQiwBzumKn/K4+1rL19o81Xi/U6x41XowwpC4MdTqxJcWhlFWEtJ8yScxig7\nHiCSFvtTbbtMGGy9JLpPS5N+TrOu5HIEXZ6DZbnZp+E495bZRdrckFjEsaIrssV+\nMA7wiOfESCGqFk8073+/X5/4eWAVzBHNtROdqpCJKs8EdV/nUHTxX0UxSYm4Jccp\ndx3ZHs9b19Hl4zAE1/osqR8VVxM8QRCOtCxWsY0Ltdj7lHMAtm4pqUlh/E3fq/3/\n0pzfwQlPAgMBAAECggEACTMJtzM9OZHiNabnks8oFVj6eicc60B8Ztt2BitG461P\ne5B//VGa0ikzMYlRpTGAXYFl8WK3kvNmC9Yn9t9m4MB1yBzAWM7IPdAwu1IGJnya\nV/Vbs3jhX5Ss1PA7IwwGLDXYbW7eTyQV5Dgl25EUN6ly3qLXmp2nB28K6sqW3o9G\n4YYAyvoXes5GQAYUOcpWVaXcIXl2VFPhOUjmcqkE7CA44/X3JTDQHUjw6e3b3Trl\nbeSafOr/ZnKCBHEzigjP3IYb3ZJ0fsK6X85VgeA5Cs3BUjDAPQYWCJLFMEUg9ls/\nINEXLSIEqI3VuHFd3w25O9hQ8f789tYDHUmXSCduOQKBgQDjpuV3UkpluosurdAR\nero1NWfAY2TW2D4gZB4nHReFgnuy3TW6Q1UoIRsLOs6M4Hp8AR880IwhSC4tWfQt\n8j355yyHFaFOyR6hwkp0Sh1Asy+pY13Q4pSMXpyyacUFe6RYCrpUownAXCKdwaXI\n1Fsw2AJiMJ8uyflFcaLMX8BAfQKBgQC60jnXaMXwhbLhFLCRcPzuGf0V/klZ+nyB\nv44CYY3FgCXzVmAdpREdadnD32ceVIP6DjAW4049fWDFAvMxloUevwBrB/P9DWqI\nDgdkw7h7C8ircPNjYd7CnxSx3rETgK+FgjJrHt3rrzAHW5M4E2muN8tjd6EOlxNM\nLjLg0DsGuwKBgHiJCb5f59xtJPyWMzDOFoHNwR1wgxfubxafbAexs56RNAXEcooo\n1JHm1XbgsDSPNsspnOyKT2ff2/NPSaZ6OK505HKx1TLt8jYbtWhVRZ/YQEgjwKy1\nC4o3HiipMBRzHtUu+PGPUb50CjAVND5dkdsOxFRRAje34TAPtu8XU6fRAoGALMcO\njg7Swp+JDGHFIFcQiJE6E/dq5WIgTYj4JKH1NQ1OC1D8oJ5bx80DIOt+78oaB+k2\npYW9zwcqFo5qc8w8A+6LzxuM424/xnR2WTSAFx3v7weXjo56sfMnJqrVjnMdnsZi\nB0LStha7UEgmtR4SCmvdF+4ocDLNsUixcSj3vNkCgYEAkVayV9eAPpmwziegrvUX\nSP+agK95HDzren8qnzuuQCan5+zUPFZLmuS/3eCAP5QBaUpI9bCp8t54oxclvhl4\nB7M7S9xoYEsiUyStfYgL5s/7Lr5/JShmy8N4MF3BR5RRDFa7o8gat1qS8P/WXgzb\nHy/nOM1hfvg+suLsnVHjEy8=\n-----END PRIVATE KEY-----\n",
  client_email:
    "contact-form-gynoveda-web@charming-well-424808-a3.iam.gserviceaccount.com",
  client_id: "106841440253291716412",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    "https://www.googleapis.com/robot/v1/metadata/x509/contact-form-gynoveda-web%40charming-well-424808-a3.iam.gserviceaccount.com",
  universe_domain: "googleapis.com",
};

export default secrets;
